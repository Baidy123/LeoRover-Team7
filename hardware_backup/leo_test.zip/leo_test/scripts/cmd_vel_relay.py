#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class CmdVelRelay(Node):
    def __init__(self):
        super().__init__('cmd_vel_relay')
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.sub = self.create_subscription(
            Twist, '/cmd_vel_smoothed', self.cb, 10)
        self.get_logger().info('relay /cmd_vel_smoothed -> /cmd_vel')

    def cb(self, msg):
        self.pub.publish(msg)


def main():
    rclpy.init()
    rclpy.spin(CmdVelRelay())


if __name__ == '__main__':
    main()
