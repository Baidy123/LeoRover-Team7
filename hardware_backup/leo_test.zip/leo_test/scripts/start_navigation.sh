#!/usr/bin/env bash
# Run AFTER `ros2 launch leo_test real_robot.launch.py` has been up ~30s.
# Brings all Nav2 lifecycle nodes to active [3] and starts the
# /cmd_vel_smoothed -> /cmd_vel relay (works around missing nav2_bringup remap).

set -u

source /opt/ros/jazzy/setup.bash
source /home/team7/ros2_ws/install/setup.bash
source /home/team7/leo_test/install/setup.bash

NODES=(/controller_server /planner_server /behavior_server /bt_navigator \
       /smoother_server /velocity_smoother /waypoint_follower)

echo "[1/3] Configuring + activating Nav2 lifecycle nodes..."
for n in "${NODES[@]}"; do
  ros2 lifecycle set "$n" configure 2>/dev/null
  ros2 lifecycle set "$n" activate  2>/dev/null
done

echo "[2/3] Lifecycle states:"
all_active=1
for n in "${NODES[@]}"; do
  s=$(ros2 lifecycle get "$n" 2>/dev/null)
  echo "  $n: $s"
  [[ "$s" != "active [3]" ]] && all_active=0
done

echo "[3/3] /cmd_vel relay (smoothed -> /cmd_vel)..."
if pgrep -f cmd_vel_relay.py >/dev/null; then
  echo "  relay already running (pid=$(pgrep -f cmd_vel_relay.py | tr '\n' ' '))"
else
  nohup python3 /home/team7/leo_test/scripts/cmd_vel_relay.py \
    >/tmp/cmd_vel_relay.log 2>&1 &
  disown
  sleep 1
  if pgrep -f cmd_vel_relay.py >/dev/null; then
    echo "  relay started (pid=$(pgrep -f cmd_vel_relay.py)). log: /tmp/cmd_vel_relay.log"
  else
    echo "  ERROR: relay failed to start. See /tmp/cmd_vel_relay.log"
    exit 2
  fi
fi

if [[ $all_active -eq 1 ]]; then
  echo "DONE. Send a 2D Goal Pose in RViz."
else
  echo "WARN: not all nodes active. Check launch log /tmp/launch.log."
  exit 1
fi
