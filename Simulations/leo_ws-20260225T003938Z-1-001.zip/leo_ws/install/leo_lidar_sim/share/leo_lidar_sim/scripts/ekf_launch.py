from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from pathlib import Path

def generate_launch_description():
    pkg_share = get_package_share_directory('leo_nav2')
    ekf_config = Path(pkg_share) / 'config' / 'ekf.yaml'

    return LaunchDescription([
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[str(ekf_config)]
        )
    ])
