#!/usr/bin/env python3

import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    
    pkg_leo_lidar_sim = get_package_share_directory('leo_lidar_sim')
    
    urdf_file = os.path.join(pkg_leo_lidar_sim, 'urdf', 'leo_with_visible_arm.urdf.xacro')
    world_file = os.path.join(pkg_leo_lidar_sim, 'worlds', 'sorting_room.sdf')
    rviz_config = os.path.join(pkg_leo_lidar_sim, 'rviz', 'leo_sim.rviz')
    lidar_model = os.path.join(pkg_leo_lidar_sim, 'models', 'lidar_sensor', 'model.sdf')
    
    robot_description = ParameterValue(
        Command(['xacro ', urdf_file]),
        value_type=str
    )
    
    #1. Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'robot_description': robot_description
        }]
    )
    
    # 2. Gazebo
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )
    
    # 3. Spawn Leo
    spawn_leo = TimerAction(
        period=5.0,
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'run', 'ros_gz_sim', 'create',
                     '-name', 'leo',
                     '-topic', 'robot_description',
                     '-x', '1.8', '-y', '-1.8', '-z', '0.3'],
                output='screen'
            )
        ]
    )
    
    # 4. Spawn LiDAR
    spawn_lidar = TimerAction(
        period=7.0,
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'run', 'ros_gz_sim', 'create',
                     '-name', 'lidar_sensor',
                     '-file', lidar_model,
                     '-x', '1.8', '-y', '-1.8', '-z', '0.5'],
                output='screen'
            )
        ]
    )
    
    # 5. Bridges
    bridge_clock = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
                output='screen'
            )
        ]
    )
    
    bridge_cmd_vel = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=['/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist'],
                output='screen'
            )
        ]
    )
    
    bridge_odom = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=['/odom@nav_msgs/msg/Odometry[gz.msgs.Odometry'],
                output='screen'
            )
        ]
    )
    
    bridge_scan = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=['/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan'],
                output='screen'
            )
        ]
    )
    
    bridge_joint_states = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=['/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model'],
                output='screen'
            )
        ]
    )
    
    bridge_camera_color = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=['/realsense/color/image@sensor_msgs/msg/Image[gz.msgs.Image'],
                output='screen'
            )
        ]
    )
    
    bridge_camera_depth = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='ros_gz_bridge',
                executable='parameter_bridge',
                arguments=['/realsense/depth/image@sensor_msgs/msg/Image[gz.msgs.Image'],
                output='screen'
            )
        ]
    )
    
    camera_info = TimerAction(
        period=9.0,
        actions=[
            Node(
                package='leo_lidar_sim',
                executable='camera_info_publisher.py',
                name='camera_info_publisher',
                output='screen',
                parameters=[{'use_sim_time': True}]
            )
        ]
    )
    
    # 6. TF Publishers
    odom_to_tf = TimerAction(
        period=11.0,
        actions=[
            Node(
                package='leo_lidar_sim',
                executable='odom_to_tf.py',
                name='odom_to_tf',
                output='screen',
                parameters=[{'use_sim_time': True}]
            )
        ]
    )
    
    lidar_tf = TimerAction(
        period=11.0,
        actions=[
            Node(
                package='tf2_ros',
                executable='static_transform_publisher',
                name='lidar_tf',
                arguments=['0', '0', '0.2', '0', '0', '0', 
                          'base_link', 'lidar_sensor/lidar_link/lidar'],
                parameters=[{'use_sim_time': True}]
            )
        ]
    )
    
    # 7. SLAM - INLINE PARAMETERS
    slam = TimerAction(
        period=13.0,
        actions=[
            Node(
                package='slam_toolbox',
                executable='async_slam_toolbox_node',
                name='slam_toolbox',
                output='screen',
                parameters=[{
                    'use_sim_time': True,
                    'odom_frame': 'odom',
                    'map_frame': 'map',
                    'base_frame': 'base_footprint',
                    'scan_topic': '/scan',
                    'mode': 'mapping',
                    'transform_publish_period': 0.02,
                    'map_update_interval': 1.0,
                    'resolution': 0.05,
                    'max_laser_range': 10.0,
                    'minimum_time_interval': 0.5,
                    'transform_timeout': 0.2,
                    'tf_buffer_duration': 30.0,
                    'use_scan_matching': True,
                    'use_scan_barycenter': True,
                    'minimum_travel_distance': 0.2,
                    'minimum_travel_heading': 0.2,
                    'scan_buffer_size': 10,
                    'scan_buffer_maximum_scan_distance': 10.0,
                    'link_match_minimum_response_fine': 0.1,
                    'link_scan_maximum_distance': 1.5,
                    'do_loop_closing': True,
                    'loop_search_maximum_distance': 3.0,
                    'loop_match_minimum_chain_size': 10,
                    'loop_match_maximum_variance_coarse': 3.0,
                    'loop_match_minimum_response_coarse': 0.35,
                    'loop_match_minimum_response_fine': 0.45,
                }]
            )
        ]
    )
    
    # 8. RViz
    rviz = TimerAction(
        period=15.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2',
                arguments=['-d', rviz_config],
                output='screen',
                parameters=[{'use_sim_time': True}]
            )
        ]
    )
    
    return LaunchDescription([
        robot_state_publisher,
        gazebo,
        spawn_leo,
        spawn_lidar,
        bridge_clock,
        bridge_cmd_vel,
        bridge_odom,
        bridge_scan,
        bridge_joint_states,
        bridge_camera_color,
        bridge_camera_depth,
        camera_info,
        odom_to_tf,
        lidar_tf,
        slam,
        rviz
    ])
