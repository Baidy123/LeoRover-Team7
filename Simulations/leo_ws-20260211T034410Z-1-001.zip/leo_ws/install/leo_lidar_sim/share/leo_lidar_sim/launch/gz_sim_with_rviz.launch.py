import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Get package directories
    pkg_leo_lidar_sim = get_package_share_directory('leo_lidar_sim')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')
    
    # Files
    rviz_config = os.path.join(pkg_leo_lidar_sim, 'rviz', 'leo_sim.rviz')
    
    # Launch arguments
    gz_args = LaunchConfiguration('gz_args')
    use_sim_time = LaunchConfiguration('use_sim_time')
    
    declare_gz_args = DeclareLaunchArgument(
        'gz_args',
        default_value='',
        description='Arguments passed to Gazebo'
    )
    
    declare_use_sim_time = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation clock'
    )
    
    # Include original Gazebo launch
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={
            'gz_args': gz_args
        }.items()
    )
    
    # Launch RViz with config
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': use_sim_time}],
        output='screen'
    )
    
    return LaunchDescription([
        declare_gz_args,
        declare_use_sim_time,
        gazebo,
        rviz
    ])
